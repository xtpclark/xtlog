CREATE OR REPLACE FUNCTION public.login() RETURNS integer AS $$
-- Copyright (c) 1999-2014 by OpenMFG LLC, d/b/a xTuple. 
-- See www.xtuple.com/CPAL for the full text of the software license.
DECLARE 
  _p RECORD;

BEGIN

  RETURN login(false);

END;
$$ LANGUAGE 'plpgsql';


CREATE OR REPLACE FUNCTION public.login(boolean)
  RETURNS integer AS
$BODY$
-- Copyright (c) 1999-2014 by OpenMFG LLC, d/b/a xTuple. 
-- See www.xtuple.com/CPAL for the full text of the software license.
DECLARE 
  _setSearchPath ALIAS FOR $1;
  _p RECORD;

BEGIN

  -- added support for PostgreSQL 9.2.0, Incident 21852
  IF (compareversion('9.2.0') <= 0)
  THEN
    PERFORM pg_try_advisory_lock(datid::integer, pid)
     FROM pg_stat_activity
    WHERE(pid = pg_backend_pid());

       IF (packageIsEnabled('xtlog') = 't')
        THEN
          -- Logging to xtlog   
          INSERT INTO xtlog.xtlog (xtlog_username, xtlog_status, xtlog_application, xtlog_backend_start)
            SELECT getEffectiveXtUser(), 'A', application_name, backend_start 
            FROM pg_stat_activity 
          WHERE pid=pg_backend_pid();
       END IF;
    
  ELSE
    PERFORM pg_try_advisory_lock(datid::integer, procpid)
     FROM pg_stat_activity
    WHERE(procpid = pg_backend_pid());

     IF (packageIsEnabled('xtlog') = 't')

      THEN
         -- Logging to xtlog 
      INSERT INTO xtlog.xtlog (xtlog_username, xtlog_status, xtlog_application, xtlog_backend_start)
        SELECT getEffectiveXtUser(), 'A', application_name, backend_start 
          FROM pg_stat_activity 
        WHERE procpid=pg_backend_pid();
     END IF;
  
  END IF;

  -- This is new to version 9.0 and higher and will error on older versions
  IF (compareversion('9.0.0') <= 0) THEN
    SET bytea_output TO escape;
  END IF;

  SELECT usr_id, userCanLogin(usr_username) AS usr_active INTO _p
  FROM usr
  WHERE (usr_username=getEffectiveXtUser());
  
  
  IF (NOT FOUND) THEN
    RETURN -1;

  ELSIF (NOT _p.usr_active) THEN
    IF(SELECT metric_value='AdminOnly'
         FROM metric
        WHERE metric_name='AllowedUserLogins') THEN
      RETURN -3;
    END IF;
    RETURN -2;
  END IF;

  IF (_setSearchPath) THEN
    IF EXISTS(SELECT 1
                FROM pg_proc
                JOIN pg_namespace ON (pronamespace=pg_namespace.oid)
               WHERE nspname='public'
                 AND proname='buildsearchpath') THEN
      EXECUTE 'SET SEARCH_PATH TO ' || public.buildSearchPath();
    END IF;
  END IF;

  RETURN 1;

END;
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION public.login(boolean)
  OWNER TO admin;
